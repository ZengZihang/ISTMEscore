#' @title ISTMEscore_subtype
#'
#' @description  identify the novel 4 TME subtypes in Zeng's study.
#'
#' @param data the input of expression data
#'
#' @param threshold_immune threshold of immune score is a 0-1 number, and default is 0.5.
#'
#' @param threshold_stromal threshold of stromal score is a 0-1 number, and default is 0.5.
#'
#' @return TME subtype
#'
#' @examples NULL
#'
#' @export ISTMEscore_subtype

ISTMEscore_infer<- function(data,threshold_immune,threshold_stromal)
{
  scores=ISTMEscore_score(data)
  group=rep(NA,ncol(data))
  group[which(scores$immune_score<=quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score<=quantile(scores$stromal_score,probs=threshold_stromal))]="immune_L & stromal_L"
  group[which(scores$immune_score>quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score>quantile(scores$stromal_score,probs=threshold_stromal))]="immune_H & stromal_H"
  group[which(scores$immune_score>quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score<=quantile(scores$stromal_score,probs=threshold_stromal))]="immune_H & stromal_L"
  group[which(scores$immune_score<=quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score>quantile(scores$stromal_score,probs=threshold_stromal))]="immune_L & stromal_H"
  names(group)=colnames(data)
  return(group)}

ISTMEscore_subtype<- function(data,threshold_immune,threshold_stromal)
{
  if (missing(threshold_immune)) threshold_immune=0.5
  if (missing(threshold_stromal)) threshold_stromal=0.5
  group=ISTMEscore_infer(data,threshold_immune,threshold_stromal)
  return(group)
}

