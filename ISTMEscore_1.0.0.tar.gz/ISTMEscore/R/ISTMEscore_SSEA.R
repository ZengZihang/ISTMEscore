#' @title ISTMEscore_SSEA
#'
#' @description We proposed sample-set enrichment analysis (SSEA) to identify genes highly expressed in specific TME subtypes.
#'
#' @examples NULL
#'
#' @export ISTMEscore_SSEA




ISTMEscore_SSEA_cal<-function(data,group,multigroup,threshold_anova_p,nPerm){

  geneset=data.frame(term=group,gene=names(group))

  genes=apply(data,1,function(x){summary(aov(x~group))[[1]][5][[1]][1]})

  genes=p.adjust(genes,method="BH")
  genes=names(genes[genes<threshold_anova_p])




  listGENE=list()

  for (t in 1:length(genes)){
    listGENE[t]=genes[t]
  }


  GSEA=clusterProfiler::GSEA
  SSEA=function(gene){
    gene=gene
    geneList=as.numeric(scale(t(data[gene,])[,1]))
    names(geneList)=colnames(data)
    geneList=geneList[order(-geneList)]
    egmt <- GSEA(geneList, TERM2GENE=geneset, verbose=F,nPerm = nPerm)
    return(egmt@result)
  }

list_SSEA=lapply(listGENE, SSEA)



  names(list_SSEA)=genes

  listGENEname=lapply(list_SSEA,function(x){return(x[x$NES>0,])})
  if (multigroup==T){
  listGENEname=lapply(listGENEname,function(x){return(x$ID)})
  }else{


    listGENEname=lapply(listGENEname,function(x){if(nrow(x)>1){return(NA)}else{return(x$ID[x$NES>0])}})

  }
  listGENEname=unlist(listGENEname)
  listGENEname=data.frame(ID=names(listGENEname),group=listGENEname)
  listGENEname=listGENEname[complete.cases(listGENEname),]
  return(listGENEname)

}

ISTMEscore_SSEA<-function(data,group,multigroup,threshold_anova_p,nPerm){
  if (missing(data)) stop("There is no data.")
  if (missing(multigroup)) multigroup=T
  if (missing(threshold_anova_p)) threshold_anova_p=0.0001
  if (missing(nPerm)) nPerm=100

  listSSEA=ISTMEscore_SSEA_cal(data,group,multigroup,threshold_anova_p,nPerm)
  return(listSSEA)
}

