#' @title ISTMEscore_read
#'
#' @description Data Reading and Standardization of ISTMEscore.
#'
#' @param inputdata the input of expression data
#'
#' @param GPL the probe annotation from GEO database
#'
#' @param rank_row logical value. Rank-based standardization in each rows. The default value is FALSE
#'
#' @param rank_col logical value (TURE or FALSE). Rank-based standardization in each columns. Gene rank expression=ascending order of raw gene expression/number of total genes (max=1, min=1/number of total genes). The default value is FALSE
#'
#' @param log2 logical value. log2(x+1) standardization. The default value is FALSE
#'
#' @param z_score logical value. Z-score standardization. The default value is FALSE
#'
#' @param min_max logical value. min_max standardization. min_max gene expression=(raw gene expression -min expression)/(max expressio-min expression). Max=1 and min=0. The default value is FALSE
#'
#' @param datatype data type of input data. "CEL" is the raw chip CEL files. "chip_matrix" is the gene expression matrix. The default value is "chip_matrix"
#'
#' @param aggregatemethod aggregate method when the gene matches multi-probes containing. "max", "min", "mean" and "median". The default value is "max"
#'
#' @param probe_first Do you want to keep probes that match multiple genes? TURE is deletion, and FALSE retains the first matching gene. The default value is TRUE
#'
#' @param raw_standard standardization methods for the CEL data, including "RMA" and "MAS5". The default value is "RMA"
#'
#' @param Ngene which column is gene symbol in GPL file
#'
#' @return A data.frame
#'
#' @examples NULL
#'
#' @export ISTMEscore_read


ISTMEscore_standard<- function(inputdata, GPL, rank_col, rank_row, log2, z_score, min_max, datatype, aggregatemethod, probe_first, raw_standard, Ngene)
{

  Numer=function(data){
    data=as.data.frame(apply(data,2,as.character))
    data=as.data.frame(apply(data,2,as.numeric))
    return(data)
  }
  data=inputdata
  if(datatype=="CEL"){
    require(affy)
          print("..Data reading...")
          data <- affy::ReadAffy(celfile.path = data)
          print("..standardization...")
          if (raw_standard=="RMA"){
          data<- affy::rma(data)}
          if (raw_standard=="MAS5"){
          data<- affy::mas5(data)}
          data= affy::exprs(data)
          print("..Annotation...")
          GPL=read.table(GPL, comment.char = "#",fill = TRUE,sep="\t",as.is=T, quote = "")
          colnames(GPL)=as.character(t(GPL[1,])[,1])
          GPL=GPL[-1,]
          matchprobe=match(rownames(data),as.character(GPL$ID))
          matchgene=GPL[,Ngene][matchprobe]

          if(probe_first== T){
            genesymbol=1: length(matchgene)
            split=strsplit(matchgene, "/// ")
            for(t in 1:length(matchgene)){
              genesymbol[t]=split[[t]][1]}
            data=Numer(data)
            data=cbind(genesymbol,data)
            zero=match(data$genesymbol,"")
            data=data[is.na(zero),]
            data=aggregate(.~genesymbol,data=data,aggregatemethod)
            rownames(data)=data[,1]
            data=data[,-1]}
          if(probe_first== F){
            exgene=grep(pattern="///", x=matchgene, value=TRUE)
            exnumber=match(exgene,matchgene)
            data=Numer(data)
            data=cbind(matchgene,data)
            data=data[-exnumber,]
            zero=match(data$matchgene,"")
            data=data[is.na(zero),]
            data=aggregate(.~matchgene,data=data,aggregatemethod)
            rownames(data)=data[,1]
            data=data[,-1]}
          print("..Standardization...")
          if(rank_col==F & rank_row==F){
            if(log2==F){data=data}else{data=log2(data+1)}
            if(z_score ==T & min_max ==T){
              data=scale(data)
              range<- apply(data, 2, max)-apply(data,2,min)
              data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")}
            if(z_score ==F & min_max ==T){
              range<- apply(data, 2, max)-apply(data,2,min)
              data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")
              }
            if(z_score ==T & min_max ==F){
              data=scale(data)
            }else if( rank_row==T){
              data_nor=rownames(data)
              for (m in 1:ncol(data)){
                AA=rank(data[,m],na.last = "keep")
                AA=AA/(nrow(data)-sum(is.na(AA)))
                data_nor=data.frame(data_nor,AA) }
              data_nor=data_nor[,-1]
              rownames(data_nor)=rownames(data)
              colnames(data_nor)=colnames(data)
              data= data_nor
            }else if( rank_col==T){
              data=t(data)
              data_nor=rownames(data)
              for (m in 1:ncol(data)){
                AA=rank(data[,m],na.last = "keep")
                AA=AA/(nrow(data)-sum(is.na(AA)))
                data_nor=data.frame(data_nor,AA)}
              data_nor=data_nor[,-1]
              rownames(data_nor)=rownames(data)
              colnames(data_nor)=colnames(data)
              data=t(data_nor)}
          }
          print("..Done...")
          }
        if(datatype=="chip_matrix"){
            print("..Data reading...")
            data <- read.table(data, comment.char = "!",fill = TRUE,sep="\t", quote = "",strip.white = TRUE)
            colnames(data)=as.character(t(data[1,])[,1])
            data=data[-1,]
            replace=gsub(pattern = "\"",replacement = "",x = data[,1])
            data[,1]=replace
            replace=gsub(pattern = "\"",replacement = "",x = colnames(data))
            colnames(data)=replace
            print("..Annotation...")
            GPL=read.table(GPL, comment.char = "#",fill = TRUE,sep="\t",as.is=T, quote = "")
            colnames(GPL)=as.character(t(GPL[1,])[,1])
            GPL=GPL[-1,]
            matchprobe=match(as.character(data[,1]),as.character(GPL$ID))
            matchgene=GPL[,Ngene][matchprobe]
            data=data[,-1]

            if(probe_first== T){
              genesymbol=1: length(matchgene)
              split=strsplit(matchgene, "/// ")
              for(t in 1:length(matchgene)){
                genesymbol[t]=split[[t]][1]}
              data=Numer(data)
              data=cbind(genesymbol,data)
              zero=match(data$genesymbol,"")
              data=data[is.na(zero),]
              data=aggregate(.~genesymbol,data=data,aggregatemethod)
              rownames(data)=data[,1]
              data=data[,-1]}
            if(probe_first== F){
              exgene=grep(pattern="///", x=matchgene, value=TRUE)
              exnumber=match(exgene,matchgene)
              data=Numer(data)
              data=cbind(matchgene,data)
              data=data[-exnumber,]
              zero=match(data$matchgene,"")
              data=data[is.na(zero),]
              data=aggregate(.~matchgene,data=data,aggregatemethod)
              rownames(data)=data[,1]
              data=data[,-1]}
            print("..Standardization...")
            if(rank_col==F & rank_row==F){
              if(log2==F){data=data}else{data=log2(data+1)}
              if(z_score ==T & min_max ==T){
                data=scale(data)
                range<- apply(data, 2, max) - apply(data,2,min)
                data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")}
              if(z_score ==F & min_max ==T){
                range<- apply(data, 2, max) - apply(data,2,min)
                data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")
                }
              if(z_score ==T & min_max ==F){
                data=scale(data)
              }else if( rank_row==T){
                data_nor=rownames(data)
                for (m in 1:ncol(data)){
                  AA=rank(data[,m],na.last = "keep")
                  AA=AA/(nrow(data)-sum(is.na(AA)))
                  data_nor=data.frame(data_nor,AA) }
                data_nor=data_nor[,-1]
                rownames(data_nor)=rownames(data)
                colnames(data_nor)=colnames(data)
                data= data_nor
              }else if( rank_col==T){
                data=t(data)
                data_nor=rownames(data)
                for (m in 1:ncol(data)){
                  AA=rank(data[,m],na.last = "keep")
                  AA=AA/(nrow(data)-sum(is.na(AA)))
                  data_nor=data.frame(data_nor,AA)}
                data_nor=data_nor[,-1]
                rownames(data_nor)=rownames(data)
                colnames(data_nor)=colnames(data)
                data=t(data_nor)}}
            print("..Done...")
            }
            return(data)}



ISTMEscore_read<- function(inputdata, GPL, rank_col, rank_row, log2, z_score, min_max, datatype, aggregatemethod, probe_first, raw_standard, Ngene){
  if (missing(inputdata)) stop("There is no data.")
  if (missing(datatype)) datatype="chip_matrix"
  if (missing(aggregatemethod)) aggregatemethod="max"
  if (missing(z_score)) z_score =F
  if (missing(min_max)) min_max=F
  if (missing(rank_col)) rank_col=F
  if (missing(rank_row)) rank_row=F
  if (missing(probe_first)) probe_first= T
  if (missing(log2)) log2=F
  if (missing(raw_standard)) raw_standard="RMA"
  if (missing(Ngene)) stop("Which column is gene symbol in GPL file?")
  data=ISTMEscore_standard(inputdata, GPL, rank_col, rank_row, log2, z_score, min_max, datatype, aggregatemethod, probe_first, raw_standard, Ngene)
  return(data)
}




