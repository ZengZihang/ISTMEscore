# Identification of the novel 4 TME subtypes in Zeng's study
# Author: Zi-hang Zeng
# Description: This function is used to identify the novel 4 TME subtypes in Zeng's study based on bulk transcriptome
#
# Param:
# data: the data.frame of gene expression data. The data can be creative by ISTMEscore_standard function. The names of row are gene symbols, and the names of column are sample ID
# threshold_immune: threshold of immune score is a 0-1 number, and default is 0.5.
# threshold_stromal: threshold of stromal score is a 0-1 number, and default is 0.5.


ISTMEscore_subtype<- function(data,threshold_immune,threshold_stromal)
{
  if (missing(threshold_immune)) threshold_immune=0.5
  if (missing(threshold_stromal)) threshold_stromal=0.5
  scores=ISTMEscore_score(data)
  group=rep(NA,ncol(data))
  group[which(scores$immune_score<=quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score<=quantile(scores$stromal_score,probs=threshold_stromal))]="immune_L & stromal_L"
  group[which(scores$immune_score>quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score>quantile(scores$stromal_score,probs=threshold_stromal))]="immune_H & stromal_H"
  group[which(scores$immune_score>quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score<=quantile(scores$stromal_score,probs=threshold_stromal))]="immune_H & stromal_L"
  group[which(scores$immune_score<=quantile(scores$immune_score,probs=threshold_immune) & scores$stromal_score>quantile(scores$stromal_score,probs=threshold_stromal))]="immune_L & stromal_H"
  names(group)=colnames(data)
  return(group)}
