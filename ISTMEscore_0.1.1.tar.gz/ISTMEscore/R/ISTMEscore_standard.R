# Data Reading and Standardization of ISTMEscore
# Author: Zi-hang Zeng
# Description: This function is used to reading gene expression data and standardization, which is particularly suitable for GEO data.
# If you need to calculate the Zeng's immune and stromal scores, We recommend setting z_score and min_max to TRUE.
# Param:
# inputdata: the input gene expression data
# GPL: the probe annotation file from GEO database
# rank_col: logical value (TURE or FALSE). Rank-based standardization in each columns. Gene rank expression=ascending order of raw gene expression/number of total genes (max=1, min=1/number of total genes). The default value is FALSE
# rank_row: logical value. Rank-based standardization in each rows. The default value is FALSE
# log2: logical value. log2(x+1) standardization. The default value is FALSE
# z_score: logical value. Z-score standardization. The default value is FALSE
# min_max: logical value. min_max standardization. min_max gene expression=(raw gene expressio -min of the sample gene expression)/(max-min of the sample gene expression). Max=1 and min=0. The default value is FALSE
# datatype: data type which supports two types. "CEL" is the raw chip CEL files. "chip_matrix" is the gene expression ".txt" matrix. The default value is "chip_matrix"
# aggregatemethod: aggregate method of the gene with multi probes containing "max", "min", "mean" and "median". The default value is "max"
# probe_first: whether to retain the probes matching multiple genes. TURE is delete, and FALSE retains the first gene. The default value is TRUE
# raw_standard: standardization methods of the raw chip data with CEL format, including "RMA" and "MAS5". The default value is "RMA"
# Ngene: which column is gene symbol in GPL file

ISTMEscore_standard<- function(inputdata, GPL, rank_col, rank_row, log2, z_score, min_max, datatype, aggregatemethod, probe_first, raw_standard, Ngene)
{
  if (missing(inputdata)) stop("There is no data.")
  if (missing(datatype)) datatype="chip_matrix"
  if (missing(aggregatemethod)) aggregatemethod="max"
  if (missing(z_score)) z_score =F
  if (missing(min_max)) min_max=F
  if (missing(rank_col)) rank_col=F
  if (missing(rank_row)) rank_row=F
  if (missing(probe_first)) probe_first= T
  if (missing(log2)) log2=F
  if (missing(raw_standard)) raw_standard="RMA"
  if (missing(Ngene)) stop("Which column is gene symbol in GPL file?")
  Numer=function(data){
    data=as.data.frame(apply(data,2,as.character))
    data=as.data.frame(apply(data,2,as.numeric))
    return(data)
  }
  data=inputdata
        if(datatype=="CEL"){
          if(require("affy")){
            print("...load Affy package...")
          } else {
            print("install Affy package")
            if (!requireNamespace("BiocManager", quietly = TRUE))
              install.packages("BiocManager")
            BiocManager::install("affy")
            library(affy)
            if(require("affy")){
              print("...affy has been successfully installed...")
            } else {
              stop("...affy installation failed...")
            }
          }
          print("..Data reading...")
          data <- ReadAffy(celfile.path = data)
          print("..standardization...")
          if (raw_standard=="RMA"){
          data<- rma(data)}
          if (raw_standard=="MAS5"){
          data<- mas5(data)}
          data= exprs(data)
          print("..Annotation...")
          GPL=read.table(GPL, comment.char = "#",fill = TRUE,sep="\t",as.is=T, quote = "")
          colnames(GPL)=as.character(t(GPL[1,])[,1])
          GPL=GPL[-1,]
          matchprobe=match(rownames(data),as.character(GPL$ID))
          matchgene=GPL[,Ngene][matchprobe]
          if( length(matchgene[is.na(matchgene)])!=0){
            stop("None of the probes are matched here.")}
          if(probe_first== T){
            genesymbol=1: length(matchgene)
            split=strsplit(matchgene, "/// ")
            for(t in 1:length(matchgene)){
              genesymbol[t]=split[[t]][1]}
            data=Numer(data)
            data=cbind(genesymbol,data)
            zero=match(data$genesymbol,"")
            data=data[is.na(zero),]
            data=aggregate(.~genesymbol,data=data,aggregatemethod)
            rownames(data)=data[,1]
            data=data[,-1]}
          if(probe_first== F){
            exgene=grep(pattern="///", x=matchgene, value=TRUE)
            exnumber=match(exgene,matchgene)
            data=Numer(data)
            data=cbind(matchgene,data)
            data=data[-exnumber,]
            zero=match(data$matchgene,"")
            data=data[is.na(zero),]
            data=aggregate(.~matchgene,data=data,aggregatemethod)
            rownames(data)=data[,1]
            data=data[,-1]}
          print("..Standardization...")
          if(rank_col==F & rank_row==F){
            if(log2==F){data=data}else{data=log2(data+1)}
            if(z_score ==T & min_max ==T){
              data=scale(data)
              range<- apply(data, 2, max)-apply(data,2,min)
              data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")}
            if(z_score ==F & min_max ==T){
              range<- apply(data, 2, max)-apply(data,2,min)
              data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")
              warning("We do not recommend min-max normalization without z-score standardization")}
            if(z_score ==T & min_max ==F){
              data=scale(data)
            }else if( rank_row==T){
              data_nor=rownames(data)
              for (m in 1:ncol(data)){
                AA=rank(data[,m],na.last = "keep")
                AA=AA/(nrow(data)-sum(is.na(AA)))
                data_nor=data.frame(data_nor,AA) }
              data_nor=data_nor[,-1]
              rownames(data_nor)=rownames(data)
              colnames(data_nor)=colnames(data)
              data= data_nor
            }else if( rank_col==T){
              data=t(data)
              data_nor=rownames(data)
              for (m in 1:ncol(data)){
                AA=rank(data[,m],na.last = "keep")
                AA=AA/(nrow(data)-sum(is.na(AA)))
                data_nor=data.frame(data_nor,AA)}
              data_nor=data_nor[,-1]
              rownames(data_nor)=rownames(data)
              colnames(data_nor)=colnames(data)
              data=t(data_nor)}
          }
          print("..Done...")
          }
        if(datatype=="chip_matrix"){
            print("..Data reading...")
            data <- read.table(data, comment.char = "!",fill = TRUE,sep="\t", quote = "",strip.white = TRUE)
            colnames(data)=as.character(t(data[1,])[,1])
            data=data[-1,]
            replace=gsub(pattern = "\"",replacement = "",x = data[,1])
            data[,1]=replace
            replace=gsub(pattern = "\"",replacement = "",x = colnames(data))
            colnames(data)=replace
            print("..Annotation...")
            GPL=read.table(GPL, comment.char = "#",fill = TRUE,sep="\t",as.is=T, quote = "")
            colnames(GPL)=as.character(t(GPL[1,])[,1])
            GPL=GPL[-1,]
            matchprobe=match(as.character(data[,1]),as.character(GPL$ID))
            matchgene=GPL[,Ngene][matchprobe]
            data=data[,-1]
            if( length(matchgene[is.na(matchgene)])!=0){
              stop("None of the probes are matched here.")}
            if(probe_first== T){
              genesymbol=1: length(matchgene)
              split=strsplit(matchgene, "/// ")
              for(t in 1:length(matchgene)){
                genesymbol[t]=split[[t]][1]}
              data=Numer(data)
              data=cbind(genesymbol,data)
              zero=match(data$genesymbol,"")
              data=data[is.na(zero),]
              data=aggregate(.~genesymbol,data=data,aggregatemethod)
              rownames(data)=data[,1]
              data=data[,-1]}
            if(probe_first== F){
              exgene=grep(pattern="///", x=matchgene, value=TRUE)
              exnumber=match(exgene,matchgene)
              data=Numer(data)
              data=cbind(matchgene,data)
              data=data[-exnumber,]
              zero=match(data$matchgene,"")
              data=data[is.na(zero),]
              data=aggregate(.~matchgene,data=data,aggregatemethod)
              rownames(data)=data[,1]
              data=data[,-1]}
            print("..Standardization...")
            if(rank_col==F & rank_row==F){
              if(log2==F){data=data}else{data=log2(data+1)}
              if(z_score ==T & min_max ==T){
                data=scale(data)
                range<- apply(data, 2, max) - apply(data,2,min)
                data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")}
              if(z_score ==F & min_max ==T){
                range<- apply(data, 2, max) - apply(data,2,min)
                data<- sweep(sweep(data, 2, apply(data, 2, min),'-'), 2, range, "/")
                warning("We do not recommend min-max normalization without z-score standardization")}
              if(z_score ==T & min_max ==F){
                data=scale(data)
              }else if( rank_row==T){
                data_nor=rownames(data)
                for (m in 1:ncol(data)){
                  AA=rank(data[,m],na.last = "keep")
                  AA=AA/(nrow(data)-sum(is.na(AA)))
                  data_nor=data.frame(data_nor,AA) }
                data_nor=data_nor[,-1]
                rownames(data_nor)=rownames(data)
                colnames(data_nor)=colnames(data)
                data= data_nor
              }else if( rank_col==T){
                data=t(data)
                data_nor=rownames(data)
                for (m in 1:ncol(data)){
                  AA=rank(data[,m],na.last = "keep")
                  AA=AA/(nrow(data)-sum(is.na(AA)))
                  data_nor=data.frame(data_nor,AA)}
                data_nor=data_nor[,-1]
                rownames(data_nor)=rownames(data)
                colnames(data_nor)=colnames(data)
                data=t(data_nor)}}
            print("..Done...")
            }
            return(data)}
