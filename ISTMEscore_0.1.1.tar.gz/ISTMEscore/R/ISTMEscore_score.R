# Calculating immune and strmal scores based on bulk transcriptome
# Author: Zi-hang Zeng
# Description: This function .
# Param:
# data: the data.frame of gene expression data. The data can be creative by ISTMEscore_standard function. The names of row are gene symbols, and the names of column are sample ID


ISTMEscore_score<- function(data)
{
  if (missing(data)) stop("There is no data.")
  immune_list=list(immune=c('CD40LG','THEMIS','PYHIN1','TRAT1','FCRL1','SPIB','GPR174','SH2D1A','CCR4','ITK','FCRL3','C5orf20','FIGF','UBASH3A','MS4A1','CD300LG','SAMD3','ADH1B','GZMK','CHRDL1','ABI3BP','FCER2','TIFAB','P2RY12','CLEC10A','RSPO2','PCDH15','HLA-DOA','PLA2G2D','CLEC17A','CD3G','CCL19','PTPRC','C17orf87','GRIA1','CD8A','PRG4','P2RY13','SFTPC','HLA-DPB1','AADAC','EOMES','AOAH','CD1E','CCR2','CCL5','GFRA1','TFEC','CLDN18','FGL2','C4orf7','CD1B','GZMA','HLA-DPA1','SCARA5','PLEK','ZNF683','CD19','HLA-DRA','CD84','PIK3CG','NCKAP1L','CR1','WIF1','CLEC12A','KIAA0408','PIGR','CXCL13','CD74','TLR8','CHIT1','IL7R','HLA-DRB1','HLA-DQA1','COL6A6','LYZ','SFTPA2','CYBB','COL29A1','LCP1','IGJ','UBD','HLA-DQA2','CXCL9','PPYR1','IFNG','MRC1','FAM26F','B2M','CD1A','HLA-B','GBP5','ADAMDEC1','LAPTM5','C1QB','ITGB2','C1QA','SUCNR1','MARCO','HLA-C','VSIG4','F13A1','CXCL10','C1QC','HLA-A','CD163','FCGR3A','TMSL3'))
  stromal_list=list(stomal=c('MDK','RPL8','S100P','FTH1','GPR87','UBC','CLDN3','FGL1','TMSB10','HSPB1','ACTB','ITPKA','KRT19','S100A2','EEF1A2','PABPC1','RPLP0','HSP90AB1','NMU','KRT8','KRT7','EPCAM','YWHAZ','MYH9','ACTG1','NPW','MMP13','TUBA1B','ERRFI1','DSP','KRT18','P4HB','ENO1','PKM2','RHOV','ALDOA','JUP','LDHA','HMGA1','HSPA1A','MIF','TUBB','HMGB3','CYP24A1','TPI1','FAM83A','RECQL4','FN1','VEGFA','GAPDH','TK1','TUBB3','UBE2C','MYBL2','COL3A1','COL1A1','COL1A2','COL11A1'))
  data=as.matrix(data)
  if(require("GSVA")){

  } else {
    print("install GSVA package")
    if (!requireNamespace("BiocManager", quietly = TRUE))
      install.packages("BiocManager")
    BiocManager::install("GSVA")
    library(GSVA)
    if(require("GSVA")){
      print("GSVA has been successfully installed")
    } else {
      stop("GSVA installation failed")
    }
  }
    gsva_immune=t(gsva(data, immune_list, method="ssgsea",kcdf="Gaussian",ssgsea.norm=T,verbose=F))
    gsva_stromal=t(gsva(data, stromal_list, method="ssgsea",kcdf="Gaussian",ssgsea.norm=T,verbose=F))
    gsva=data.frame(immune_score=gsva_immune[,1],stromal_score=gsva_stromal[,1])
    gsva=data.frame(gsva)
    rownames(gsva)=colnames(data)
  return(gsva)
}
